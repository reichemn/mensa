angular.module('app.controllers', [])
  
.controller('foodsaverCtrl', function($scope) {

})
   
.controller('bewertungCtrl', function($scope) {

})
   
.controller('bewertung2Ctrl', function($scope) {

})
   
.controller('bewertung3Ctrl', function($scope) {

})
   
.controller('dankeCtrl', function($scope) {

})
 